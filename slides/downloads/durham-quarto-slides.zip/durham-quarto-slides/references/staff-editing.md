# Staff editing in the delivered slides

Include the bundled staff editor by default when creating or revising David's Durham Reveal.js decks, unless the user opts out. Apply it to every suitable slide in the requested deck or batch; changing this skill does not authorize changing unrelated courses.

## Staff workflow

- A small **Edit slides** button in the top-right corner opens editing without needing a shortcut. It sits outside the slide content, is visible to anyone viewing the normal HTML, and disappears in Reveal's presentation fullscreen (press **F**) and print. Exit fullscreen to edit. The toolbar stays hidden until opened. **Alt+Shift+E** remains an alternative toggle, and `?edit=1` before the slide hash opens directly in editing mode.
- Staff click outlined text to edit headings, paragraphs, bullets, table values and designated special-slide text. Layout, logos, maths, images and interactive controls stay protected. Paste inserts plain text; the existing inline emphasis and links can be retained.
- Previous/Next move between slides with all content visible. Undo restores a completed text or link edit. Click linked words and choose **Edit link** to change their label or destination.
- **Preview / present** hides the toolbar and restores presentation controls. A crowding warning prompts staff to shorten overflowing text; it is a heuristic, not a complete layout or maths check.
- **Save updated slides** downloads a complete `*-edited.html`, including assets, animations and the edit record. Staff must retain that downloaded file; typing in the browser alone does not save to disk. No login, server or authoring software is needed by the person editing the delivered file. Test current Edge/Chrome, and state any environment-specific limitations.

Anyone with the HTML can edit and save their own copy. The button/shortcut does not grant permission to update the website or master project, and is not staff authentication. Use existing delivery permissions where staff-only access matters.

## Add to a project

Copy `assets/starter/staff-editor.html` and `assets/starter/scripts/staff_edits.py` into the project. Add `staff-editor.html` to Reveal's `include-after-body`, after any deck-specific animation script. Add `python scripts/staff_edits.py` to the project's `post-render` list, preserving other hooks. Authoring/building requires an available Python 3 interpreter; use the installed runtime or adapt the hook if `python` is not on PATH. Viewing and staff editing use browser features only.

The packaging step creates a persistent `staff-edits/<rendered-name>.json` for each deck. Keep that file with the editable source: it identifies the deck and holds imported content overrides. Do not copy another deck's identity into a new project. The final HTML contains a compressed pristine build so saving does not capture Reveal's temporary navigation classes, editor controls or a running countdown.

Generic text fields are discovered automatically. Use stable `data-staff-field="name"` with `data-staff-kind="text"` on the smallest appropriate text element when special markup must survive, such as an animated quotation, cover or college name. Mark protected content or its ancestor `data-staff-lock`. Maths and functional timer output are excluded. Give source slides stable IDs.

Deck-specific playback should listen for `durham:staff-edit-mode` and stop decorative animation/pause functional timers when `event.detail.active` is true. Suppress automatic playback while the root has class `durham-staff-editing`; resume normal behaviour when editing closes. The induction deck is the working example, not a source of unrelated course content.

## Bring edits back into the master project

From that project, run:

```text
python scripts/staff_edits.py import path/to/downloaded-edited.html
quarto render
```

The importer reads the embedded JSON without executing the downloaded HTML. It updates the matching `staff-edits/*.json` companion source, rather than guessing replacements in Markdown. Subsequent renders embed those changes. Keep and transfer the QMD, companion JSON and helper together.

A different deck identity or a stale copy conflicting with newer imported staff edits is rejected. If the original QMD text or structure has changed underneath an override, the editor flags that field and refuses a new export until resolved. Inspect warnings during review, reconcile the intended wording in source/overrides, and re-render. Never silently discard conflicts or claim a source update when only the browser changed.

## Verify the actual workflow

**Light touch with the unchanged bundled helper:** check editable coverage and protected maths/widgets, the corner button and hidden toolbar, button/keyboard entry and exit, fullscreen/print suppression, a representative edit/Undo, preview, and a saved HTML reopened with its edit intact. Reuse recorded packaging/import regression results for the same helper version; do not repeat an isolated import/rebuild and stale-copy test for every converted deck. Check deck-specific animation/timer hooks when present. For a minor edit in an already verified deck, focus on the affected fields and final packaging.

**Full check or a modified editor/persistence implementation:** additionally check link editing, crowding feedback, print suppression and saved formatting/images/navigation/interactions. Import a saved edit into an isolated project and confirm it survives rebuilding; test that a stale conflicting import leaves the master unchanged. Use the bundled `scripts/test_staff_edits.py` for packaging/import regression checks. Reusing the unchanged bundled hook/configuration in a new deck remains in the light-touch route. A task that actually imports staff edits always verifies that the imported content survives its rebuild, whichever review level was selected.

Apply layout, maths and accessibility checks at the level selected in `SKILL.md`; independently check maths introduced or materially changed. Report screen-reader, direct local-file opening or platform checks as untested when the environment prevents them. A successful download notification alone is not proof that the file contains the correct saved content.
