# Optional PDF and PowerPoint downloads

Use when the user selects downloadable copies. A full review should offer this
option once, not automatically generate extra formats. For example:

> Would you like a downloadable PDF, PowerPoint, both, or neither? Generating and
> checking these can take a while, especially for a long deck or several lectures.

Existing explicit choices count; do not ask again. Continue the requested review
while a download choice is pending. Do not promise a fixed completion time without
a basis in the deck size, export method and available tools.

- Build from the current reviewed slides. Reuse an existing export only after
  verifying that it contains the same current content; do not substitute an older
  source PowerPoint after the web slides have been revised.
- Explain the PowerPoint tradeoff before choosing an export method: editable
  objects may need layout adjustments; slide images preserve the appearance but
  flatten the content. Ask when that choice is unresolved and material. Students
  can still add notes to a flattened copy. PDF is static; animations, video and
  interactive explanations remain in the HTML.
- Use the available presentation/PDF tools and their authoring guidance. Prefer
  semantic, accessible output where supported. If the chosen export is image-based,
  say so, retain useful descriptions/online links where possible, and keep the
  accessible HTML available. Do not describe a flattened copy as an editable master
  or claim accessibility checks that were not performed.
- If a download control is requested, use one small **Download** menu near the
  bottom, clear of content, footer, logo and navigation. Offer only the selected,
  completed formats and check keyboard access. Do not add an editing control.
- Check slide count/order, equations, diagrams, tables and links in the actual
  exported files. Confirm each browser capture displays the intended slide before
  packaging; a changed slide ID alone can precede the displayed frame. Render the
  exports and check for missing, repeated or clipped pages.
- For requested online delivery, follow [publishing.md](publishing.md). Keep stable
  file URLs and verify both the menu and real downloads. Regenerate affected copies
  after content changes so they stay in step with the web slides. Preserve binary
  PDF/PPTX bytes in Git and existing Blackboard link visibility.

Report which formats were delivered, whether PowerPoint content is editable or
flattened, and any remaining export limitations. Keep the editable source project.
