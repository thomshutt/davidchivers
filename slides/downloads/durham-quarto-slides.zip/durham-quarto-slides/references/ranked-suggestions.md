# Optional ranked improvements after conversion and checks

Run this pass only when the user opts in or has already requested slide suggestions/ranking. Read the completed baseline and its existing checks first. Reuse the source mapping, screenshots and figure/model information; do not re-extract or re-render a checked deck without a reason.

## Offer a bounded choice

After the baseline is complete, ask once using the available question tool, or in chat if no such tool is available:

> Would you like an optional ranked suggestions pass? It uses extra tokens to inspect clarity and teaching opportunities. Choose no extra review, a quick top-three shortlist, or a detailed review of the deck.

- **No extra review:** deliver the verified baseline and stop.
- **Quick shortlist:** inspect a bounded set of promising slides/sections from the existing evidence and return up to three specific suggestions. State what was covered; do not imply every slide received a fresh review.
- **Detailed review:** inspect the full requested deck and return a ranked shortlist, normally up to five items. Group repetitions; do not produce dozens of cosmetic suggestions.

Offer this choice once for the requested batch of decks, not once per slide or lecture. Skip the question when the user already selected a level or requested the review; use a bounded shortlist by default for an unspecified suggestions request. Silence is not opt-in. Deliver the baseline while the optional choice remains pending. Describe the extra effort qualitatively unless an actual token budget/measurement exists; do not invent a token estimate.

## Find opportunities with a teaching purpose

| Candidate | Useful suggestion | Evidence/condition to check |
| --- | --- | --- |
| A crowded derivation or unclear comparison | A sequence, clearer annotation, worked example or side-by-side comparison | Preserve qualifications and the logical argument. State any proposed change to slide count/order, and the added teaching time. |
| A table/chart with an obscured main result | Direct labels, focused emphasis, accessible table/data or a simpler comparison | Use the actual values and uncertainty. Do not discard null/contrary findings or change the estimand to make the slide cleaner. |
| A repeated explanatory diagram | A clear static figure or aligned static stages; optional controlled playback only when it adds a specific benefit | Show how the change supports the learning point. Retain the full explanation, registration and any required reduced-motion fallback. |
| Code shown as a picture or static block | Editable source/copyable example and, where useful, clear line highlighting | Identify the language and learning task. Prefer the simplest usable code example. An in-slide editor with Run/Reset is a separate, more complex proposal: verify runtime, dependencies, loading time and offline/server requirements before promising it. |
| A model/graph where changing a parameter would teach a mechanism | An optional keyboard-accessible slider or toggle, only if it improves on static comparisons | Actual equations/data must be available. Identify sensible ranges, held-fixed assumptions and invariant relationships. Label illustrative models separately from empirical estimates; provide the original static view and Reset. |

Err on simple. Prefer a clearer sentence, label, static worked example or readable comparison over additional controls when they teach the same thing. Recommend interaction only when students gain a specific useful action or understanding. Do not try to find a widget for every slide. New factual research and course-outline changes require the corresponding scope; use the content-maintenance workflow for an already requested factual refresh.

## Rank the shortlist

- Prioritize the expected learning benefit and removal of confusion, then weigh implementation effort, reliability/accessibility, teaching time and available source inputs. Use practical high/medium/low judgments; avoid falsely precise scoring.
- Anchor every item to actual slide IDs/titles and an observed limitation or opportunity. State exactly what the student/lecturer would be able to do and why that helps.
- Return a compact table: `rank | slides | proposed change and teaching benefit | effort/dependencies`. Identify the best first change. Include runtime needs only for proposals that have them. Mark suggestions requiring missing code, equations, data or a runtime as conditional rather than implementation-ready.
- Separate suggested features from unresolved baseline defects. Repair authorized baseline defects; do not dress them up as optional enhancements.
- Suggestions are proposals. Do not add widgets, execute unfamiliar example code, install runtimes, or change teaching content merely because an item ranks highly. Implement selected items when the user authorizes them; earlier explicit authorization remains valid.

Quarto's normal executable code cells produce output during rendering; they do not by themselves provide a student-editable browser runtime. Verify the intended interaction against the actual tools. See the [Reveal.js code guidance](https://quarto.org/docs/presentations/revealjs/#executable-code) when that distinction matters.
