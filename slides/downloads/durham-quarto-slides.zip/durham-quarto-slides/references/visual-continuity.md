# Visual continuity and registration

**Visual continuity** is consistency across a sequence of slides. **Registration** is the alignment of repeated visual elements, so figures/axes do not jump when moving between slides. Use this detailed workflow for a full check, changed figure sequences or an observed alignment problem. Light conversion preserves the source's geometry and includes a quick visual comparison of affected/representative sequences.

## Identify what should stay fixed

- Group related slides: a derivation, before/after comparison, successive equilibria, a figure with added annotations, or staged code/output. Include related slides separated by an explanation slide; do not restrict the check to adjacent slide numbers.
- For each group, distinguish fixed structure from intentional change. Axes, panel positions, units, scales, figure framing, symbol meanings and series colours normally stay fixed; curves, prices, quantities and annotations may change with the model's state.
- Compare like-for-like views. Do not force unrelated figures into the same axes or conceal a necessary scale change; label and explain intentional differences.

## Check the displayed geometry

1. Render at one consistent viewport and use the actual slide coordinate system. Check both the artwork's internal coordinates and its displayed CSS size/top/left. Identical SVG coordinates can still jump if the images are fitted at different sizes or have different padding.
2. Compare the figure frame, axes origins/endpoints, plot area, panel gutters, grid/price guides, ticks, labels and legend placement. Check repeated titles/captions/source notes and their clearance from the footer/logo. Aspect ratio alone is insufficient.
3. For model comparisons, verify that a common value lands at the same screen coordinate across states. Use the same price/quantity mappings when intended. For empirical charts, check units, axis limits/ticks and category order; intentional rescaling must be clear to the reader.
4. Navigate forward and backward through each group at presentation size. Look for moving axes, shrinking artwork, changed crop, label jumps, colour reassignment, reflowing text and an unintended transition. Capture paired screenshots if a discrepancy needs diagnosis.
5. Start with the rendered forward/backward comparison. Measure fixed anchors when needed to diagnose a discrepancy, or when precise registration is explicitly required. Normalize to the slide dimensions and declare a useful tolerance, for example 2 pixels on the 1600 x 900 canvas. Apply judgment for antialiasing and glyph edges; do not demand pixel equality from changing curves.
6. An overlay/blink or image difference can help locate a shift, but dynamic curves and added annotations create expected differences. Compare fixed anchors rather than interpreting every changed pixel as a defect.

## Repair and report

- Fix the common coordinate mapping, reusable layout class, SVG `viewBox`/padding or figure box. Prefer a shared generator/layout over separate per-slide offsets that accumulate drift. Avoid automatic fitting that changes the scale between states.
- Preserve the economic/data change and the original qualifications while repairing layout. Use [diagrams-and-motion.md](diagrams-and-motion.md) for diagram correctness and controlled animation.
- Re-render affected slides and repeat the forward/backward comparison. Check layout and data/economic relationships separately.
- Record material fixes and unresolved issues in the existing project QA record, identifying the slide IDs, fixed anchors/scales and intentional changes as useful. Describe the comparison actually performed; do not claim automated registration when the review was manual. A small revision does not need a new sequence register.

A complete sequence review belongs to the optional full check. Repairing a conversion-induced jump or checking a sequence changed in the current task remains within light touch. Neither requires selecting creative teaching suggestions.
