# Economic diagrams and optional playback

## Preserve the model's geometry

- Read the surrounding teaching explanation and original diagram before redrawing. Verify curves, arrow directions, equilibrium, units and welfare accounting; attractive geometry is not an economics check.
- Define shared functions mapping price/quantity to pixels. Related panels and successive states must use the same price and quantity scales where direct comparison or horizontal addition is intended. Keep axes stationary across stages.
- Draw common price guides continuously across related panels, including the spaces between panels. Put their labels at the edge or in a clear gutter. Do not cover curves, equations or welfare areas.
- For an import-demand/export-supply derivation, verify each quantity and their horizontal sum at the same price. For a tariff, verify the importer/exporter price difference equals the tariff. Label changing prices consistently across all panels.
- Distinguish tariff revenue, resource costs, transfers, consumer surplus, producer surplus and net welfare. The customs-union teaching example uses `A + B - C` for tariff removal and `A + F` for non-tariff-barrier removal; retain that model's definitions, rather than applying those letters to unrelated diagrams. Exporter net welfare combines consumer and producer effects.
- Internal illustrative coordinates can enforce relationships. Do not print invented numerical values as though they were the source's empirical estimates. Preserve symbolic notation unless numerical illustration is requested.
- Add checks of the actual relationships in the drawing generator when geometry changes. Then inspect the rendered diagram and slide: checks on model numbers cannot reveal clipped labels or inconsistent display scaling.

Working examples: `E:/AI/teaching/macro_applications_quarto/scripts/draw_customs_union.py` and Lecture 2's local SVG assets. Inspect them when useful; do not overwrite or import their course content into another deck.

## Make playback an optional explanation

Prefer a clear static diagram or a small sequence of static states when that explains the mechanism. Add playback only when its teaching purpose is clear and it is within the requested scope.

- Default to the complete static diagram, visible and useful before JavaScript runs. Start playback only after a user action. Retain a full static print/export view.
- Offer Play/Pause (Resume), a manual stage/step control and Show all/Reset. At completion, restore the complete diagram and offer Replay. Use ordinary keyboard-operable buttons with visible focus.
- Animate only the teaching relationship: for trade flows, move from the exporter to the importer, keeping nodes and the underlying arrows fixed. Give each stage enough time to read and accompany it with a short explanation.
- Preserve the full information with reduced-motion preferences. Suppress moving markers or use immediate stage highlights; ensure motion is not required to understand the diagram.
- Pause when the browser is hidden; stop/reset when leaving the slide so revisiting starts in the static view. Keep paused positions fixed and resume from those positions.
- Use unique SVG IDs per widget, a `viewBox`, a title/description and a concise live status. Scope CSS and script selectors to the widget. Hide unusable controls if initialization fails; the diagram must still explain the model.
- Test all stages and controls in the rendered deck, including static load, completion, keyboard operation, reduced motion and navigation away/back. Inspect the browser console for errors.

Working example: Lecture 2's `assets/lecture_2/framework_diagram.html`, `framework_animation.html` and the scoped `.framework-*`/`.fw-*` theme rules. This widget explains **A simple, symmetric framework**; it is not the tariff-price animation.

## Quarto raw HTML include pitfall

Wrap included SVG/HTML markup in a raw HTML fence. Indented markup can otherwise become a displayed code block and break the widget:

````markdown
```{=html}
<div class="diagram-widget">
  <svg viewBox="0 0 1400 550" role="img" aria-labelledby="diagram-title diagram-desc">
    <title id="diagram-title">Descriptive diagram title</title>
    <desc id="diagram-desc">The economic relationship and relevant directions.</desc>
    <!-- Native SVG diagram markup -->
  </svg>
</div>
```
````

Include that file from `.qmd` with `{{< include assets/diagram.html >}}` under a slide heading. A comment or raw HTML block before the first slide heading can create an unintended empty introductory slide. Put the deck's initialization script in `include-after-body`, run it after load, and verify both markup and script are embedded in the delivered HTML.
