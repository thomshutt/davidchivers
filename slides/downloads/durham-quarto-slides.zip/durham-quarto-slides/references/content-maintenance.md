# Check maths, proofread, check links and refresh current information

Use this reference for a requested **full check**, a targeted content check, or a date/data refresh. Load and apply only the sections relevant to that scope. Ordinary light-touch conversion follows the essential formatting, fidelity and delivery checks in `SKILL.md`; it does not automatically trigger independent maths verification or a complete external-link audit. Updating this skill does not itself authorize updating existing lectures.

## Check mathematical correctness

For a requested full deck check, cover every numerical example, equation and displayed derivation. For a targeted check, or maths introduced/materially changed during a revision, check that maths and dependent slides, reusing relevant verified work. Light conversion checks the fidelity and consistent presentation of preserved equations against their source; it does not rederive every result. Investigate a suspected substantive error locally and report unresolved meaning rather than silently expanding into a whole-deck audit.

- Independently recalculate arithmetic, totals, averages, percentages, rates, shares and weights. Check denominators, rounding and percentage changes versus percentage-point changes; distinguish levels from growth rates and nominal from real quantities.
- Work through each displayed derivation from its stated assumptions. Check algebraic steps, signs, inequalities, subscripts, exponents, derivatives and any equilibrium or optimality conditions used. Check units, dimensions, domains and boundary cases where relevant; define symbols consistently.
- Reconcile numerical values and economic claims across equations, tables, graph labels, diagram geometry and prose. Check that stated directions of change and interpretations follow from the model. Use [diagrams-and-motion.md](diagrams-and-motion.md) for diagram-specific relationships and welfare accounting.
- Use calculation or symbolic tools when they improve reliability. A numerical spot check can expose a mistake but does not prove a general identity or result. Matching the source, rendering successfully or producing a plausible graph is not mathematical verification.
- Correct verified errors and update dependent examples, figures and explanations together. If an assumption, source value or intended result is unclear, flag the precise unresolved step rather than guessing or silently changing the model. Keep arithmetic correctness separate from empirical or administrative validity: weights summing to 100% does not establish that they are the current assessment policy.
- Record material corrections and the scope actually checked in the existing QA record. Identify unverified calculations or derivations and what is needed to resolve them; do not report a complete maths audit when checks were partial.

## Proofread and check crowding

- Check spelling, duplicated/missing words, punctuation, heading consistency, figure/table references and terminology. Search for unfinished placeholders, example course labels and malformed year ranges. Use British English unless the source/user specifies otherwise. Correct clear mistakes within scope; preserve quotations, technical terms and intended meaning. Check mathematical symbols against the source/model before changing them.
- Inspect the rendered slide, not only its word count: can the title, explanation, graph labels and sources be read at presentation size? Look for overflowing text, tiny legends, crowded equations, several unrelated points and unexplained notation. Avoid fixed bullet/word quotas.
- Check underused space too: a text/equation block should not be compressed into one corner while most of the usable canvas is empty. Balance widths and spacing without mechanically filling the slide. Use consistent equation size, weight and alignment; remove accidental emphasis while preserving mathematical meaning and intentional highlights. These presentation checks also belong to light touch.
- Start with a clearer sentence, a useful heading, direct figure labels or improved spacing. Preserve essential qualifications and student-facing explanations. Split a crowded slide only within the authorized revision scope; otherwise flag the proposed split. Do not solve crowding by silently deleting caveats or hiding essential material in speaker notes.
- Recheck affected slides after repairs, including visual continuity with neighbouring states.

## Check links efficiently and accurately

1. Inventory internal slide anchors, local resources and external destinations. Deduplicate external URLs across the requested batch. For a requested full check, cover the complete inventory; for a narrow edit, check affected links and reuse recent recorded checks for unchanged ones. Light conversion checks local assets/anchors and preserves external destinations; verify a destination when newly added, changed, evidently broken or needed to resolve a claim. State the coverage without implying a full link audit.
2. Verify internal anchors against the rendered slide IDs, and local links/assets from the delivered file's location. A link that works only in the source folder is a delivery defect.
3. Open or request external destinations with available browsing tools. Inspect the final destination and intended resource, not just a successful HTTP response. A redirect to a homepage/login screen can lose the paper, dataset, policy or video the slide promises. Test named page/section fragments where relevant.
4. Distinguish `working`, `verified replacement`, `broken/not found`, `login required`, `blocked/timeout` and `not checked`. A failed HEAD request alone is not proof of a broken link; try an ordinary page load when appropriate. Avoid repeatedly retrying blocked resources. For institutional resources, reuse authorized sessions and follow the user's access instructions.
5. Repair the link when a verified replacement points to the same intended resource. Treat replacing an old policy with a substantively different current policy as a content refresh, with its year/context checked. Preserve useful citation/version details and flag uncertain replacements.
6. Link access, permission to read the full resource, and media playback are separate checks. Do not claim a video played or a student has licensed access merely because its landing page opens.

## Refresh academic years and administrative dates

- Establish the target **calendar year or academic year** from the request and course context. If the user says "current academic year", verify the institution/course's applicable year using an authoritative source and the current date. Use an existing explicit target without asking again. If the calendar/academic-year interpretation would change the result and context cannot settle it, ask one focused question while continuing independent checks.
- Normalize clear year-label errors against that target. For example, a confirmed refresh to **2026–2027** can update course labels saying **2025–2026**, and repair malformed labels such as **20250–2027**. Do not guess the intended range when the target is unknown.
- Check cover slides, footers, module information, current staff/contact information, timetables, deadlines and year-specific links. Verify actual dates and roles from current official course/university sources. Never move a deadline forward by exactly one year without checking the new schedule.
- Preserve historical event dates, policy periods, bibliography years, original study estimates and figure sample periods unless the requested refresh explicitly covers them. A new course year does not make an old chart's data current.
- Apply verified changes directly within the requested refresh. Flag missing or conflicting source information; do not invent a new deadline or replace a correct historical date to make the slides look current.

## Refresh statistics and figures

- Identify which statistics are intended to describe current conditions and which are historical examples or published study results. Use the original authoritative data provider where possible, and record the new release/vintage and observation period.
- Check definitions, geography, population, units, prices/base years, frequency, seasonal adjustment and revisions before treating a new series as a comparable update. Newer publication dates do not necessarily mean newer observations.
- Update the data and regenerate the chart/table where source data and code are available. Reconcile all affected labels, dates, citations, summary numbers and explanatory claims. Preserve uncertainty and contrary findings; a changed value can require a changed takeaway.
- If only an image is available, obtain the underlying data or a verified current figure. Do not relabel the old image with a new year or infer precise values from its appearance. Keep the correct existing figure and report the missing input if an update cannot be supported.
- Report comparability changes or unresolved coverage. Do not silently replace a measure with a different definition merely to obtain a recent number.

## Record only what helps verification

Use the existing project QA/conversion record for material changes and unresolved items: `slide ID | old item | change/status | source URL or file | period/vintage and date checked`. Summarize small typo fixes together. Report the target academic year, link-check coverage and data actually refreshed; never imply that a conversion alone included a full factual audit.
