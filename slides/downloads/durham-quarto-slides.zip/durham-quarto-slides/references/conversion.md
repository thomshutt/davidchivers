# Convert an existing PowerPoint or Beamer deck

Convert into Durham Quarto/Reveal.js while preserving content and verifying the result. If the request also includes a year/date/data refresh, apply [content-maintenance.md](content-maintenance.md) to those items; otherwise preserve source facts and flag dated material. Source editability and visual fidelity are separate goals; report where only one can be preserved.

## Establish the source and mapping

1. Identify the actual source file/revision, assets, notes, linked media and any existing conversion. Reuse a hand-edited `.qmd` instead of importing again. Preserve the originals; use a working copy for operations that group shapes or modify a presentation in memory.
2. Inspect the source presentation visually as well as extracting text. Inventory logical slides/frames, hidden/backup material, overlays, equations, tables, chart data, native diagrams, citations, notes, video and ink annotations. Do not silently omit unusual content.
3. Start a source-to-target mapping in the project's existing conversion record, or a small `conversion_map.csv` if none exists. Use fields `source_file,source_slide_or_frame,source_title,target_slide_id,status,limitations`. Map title slides explicitly; Quarto's generated title slide must not duplicate the original cover. Record any authorized split/merge and any unmapped item.
4. Give target slides stable IDs. Preserve the source's logical order and default slide count; explain differences from Beamer overlay-page counts. Use the selected Durham theme while retaining the source's teaching content, notation, evidence dates and qualifications.

Use ordinary fenced code blocks for source code examples so they are editable/copyable without automatically executing them during conversion. A student-editable browser editor/runtime is a separate optional enhancement.

## PowerPoint route

- Read `.pptx` package XML or use available presentation tooling to extract text, bullets, tables, pictures, hyperlinks, notes and shape geometry. Resolve the presentation's slide relationship order; do not assume alphabetic/numeric XML filenames are the teaching sequence. Geometry and reading order need visual confirmation.
- Render the original slides for comparison, using installed PowerPoint or an available compatible renderer. When PowerPoint automation is needed, work with a task-owned in-memory/temporary copy, never save over the source, and close only presentations opened for the task. Avoid disrupting the user's open Office session.
- Convert text to Markdown, tables to structured tables, and standalone equations to structured mathematical source. For Office Math, the Macro workflow extracts OMML into a temporary DOCX, reads it with Pandoc and reconciles the result against each original equation. This is a reusable technique; check signs, superscripts, primes, subscripts and symbol definitions manually.
- Extract original pictures at source resolution. For native charts/grouped diagrams, prefer a tested SVG export when it preserves artwork accurately. Include arrows, labels, grouping and annotations; compare the export with the complete source slide. An SVG is not automatically an editable chart model or a data source.
- Keep available chart data and generator code with the project. If only artwork exists, preserve it with accurate alt text and record that limitation. Rebuilding a chart from data/equations or adding interactivity needs adequate source inputs; never invent values to make a conversion work.
- Carry presenter notes into speaker notes where appropriate. Keep essential explanations visible to students. Preserve media destinations and provide a useful link/static explanation when an embed cannot work in the delivered file.

Optional Windows/local examples, when available, to inspect and adapt rather than run against a new project unchanged. They are not bundled conversion engines or prerequisites:

- `E:/AI/teaching/macro_applications_quarto/scripts/inspect_sources.py`: source text, geometry and Office Math extraction.
- `E:/AI/teaching/macro_applications_quarto/scripts/export_source_artwork.ps1`: original slide renders and selected native artwork exports.
- The initial import/build scripts in that project are course-specific and overwrite output sources. Do not rerun them over edited QMD files.

## Beamer route

- Prefer the main `.tex` plus included files, macros, bibliography, figures and the rendered PDF. Read the project build configuration; use the existing compiler when a source render is needed. Preserve original sources and the canonical source PDF.
- Map each logical `frame` to a Quarto slide. Translate frame titles, lists, blocks, columns, footnotes, tables, maths and notes into semantic Quarto structures. Resolve custom macros and referenced labels/citations instead of carrying unsupported raw TeX into HTML.
- Inspect `\pause`, `\only`, `\uncover`, `\onslide`, overlay specifications and repeated frames. Preserve their teaching information in the complete static slide. Retain controlled reveal/staging only when requested or needed to preserve an existing explanation. Record the difference between logical frames and PDF overlay pages.
- Preserve TikZ/PGF or other diagram source where available; export verified vector artwork or rebuild from that source when needed. Convert included PDF/EPS artwork through available tooling and visually check equations, fonts, transparency and cropping in the browser. Do not rely on unsupported image formats working in HTML.
- Pandoc's LaTeX reader may help with selected text/math, but its presence does not establish a faithful Beamer conversion. Check available input formats with `pandoc --list-input-formats`; do not promise a direct PPTX reader or a lossless frame/overlay/theme conversion.
- If only a PDF is available, use it as a reference and reconstruct what is recoverable. Report missing source/code/data and any retained image-only material. Do not label that result fully editable or fully accessible.

## Reconcile before delivering

- Check every source-to-target mapping, and compare all converted slides with the original renders. Verify numerical table cells, equations, citations, chart labels, source qualifications, annotations and notes/media coverage. Record unresolved losses explicitly.
- Run the main skill's render, accessibility, delivery and visual-continuity checks. Distinguish a preserved source error or outdated claim from a conversion defect; flag substantive corrections separately unless a content update is authorized.
- Deliver the editable QMD/assets, the agreed portable HTML/ZIP, the mapping and a concise limitations record. A screenshot-only slide deck is a reference copy, not the requested editable conversion.

Documentation when a specific reader/format decision needs verification: [Pandoc manual](https://pandoc.org/MANUAL.html), [Quarto Reveal.js authoring](https://quarto.org/docs/presentations/revealjs/).
