---
name: durham-quarto-slides
description: Create or convert Durham Quarto/Reveal.js teaching slides with the University logo and a simple, readable design. Check maths, typos, crowding, links and visual continuity; refresh academic years, dates or data when requested. Support PowerPoint and Beamer sources. Offer an optional ranked teaching review after the baseline checks. Keep extra review opt-in and prefer clear static slides.
---

# Durham Quarto slides

Use David's established Durham teaching design and preserve the requested teaching content. Explicit user choices override these defaults.

**Err on simple.** Prioritize clear explanations, concise language, readable figures and complete static slides. Add interaction or animation only within the requested scope and when a specific learning benefit justifies the extra complexity. A simpler static change wins when it teaches the same thing.

## Choose the requested work

- **Create or revise:** use the starter or existing Quarto source and the standards below.
- **Convert PowerPoint or Beamer:** read [conversion.md](references/conversion.md). Preserve the source's content and logical sequence, produce editable Quarto plus portable HTML, and record the source-to-target slide mapping and conversion limitations.
- **Check and repair:** use [content-maintenance.md](references/content-maintenance.md) for mathematical correctness, typos, crowding, cross-references and links. Recalculate numerical examples and work through displayed derivations; reconcile equations, graphs and explanations. Apply [visual-continuity.md](references/visual-continuity.md) to related slides: repeated graphs, axes and figures should stay aligned when advancing or reversing slides.
- **Refresh dates or data:** a request such as "update this for the current academic year" or "refresh the statistics" authorizes verified updates within that scope. Use [content-maintenance.md](references/content-maintenance.md); establish the target year/period, apply supported changes and record unresolved items. Conversion alone preserves historical evidence and administrative facts.
- **Suggest improvements:** this is an optional second pass after the baseline is converted and checked. Ask once whether the user wants a quick shortlist or a detailed ranked review, explaining that the extra review uses more tokens. Skip it unless selected; previous explicit requests for suggestions/ranking already count as opt-in. Read [ranked-suggestions.md](references/ranked-suggestions.md) only when that pass is selected. Asking to update this skill does not authorize a review of the current decks.

Every creation, conversion and revision includes the check-and-repair route, including maths where present. Required verification and repairs remain part of the baseline task. The optional gate applies to additional design/teaching suggestions, not to fixing defects in the authorized work.

## Load the working standard

- Locate the live workspace. If present, read `_shared/templates/durham_teaching_slides.md` and `_shared/standards/teaching_slides_accessibility.md` there for the canonical standards. David's current workspace is `E:/AI`, but that is a local hint, not a dependency. When those optional workspace resources are absent, use the bundled design and essential checks below with the project's own instructions.
- Identify the live project and editable `.qmd` before editing. For an existing deck, work in that source and its local assets. Do not rerun an initial import/conversion script over hand-edited slides.
- Include the hidden staff text editor in requested Reveal.js decks by default. Read [staff-editing.md](references/staff-editing.md) for its bundled helper, protected content, saving and importing edits into the master project. Preserve imported staff edits before rebuilding.
- For a new deck, copy `assets/starter/` relative to this skill into an empty project in the requested workspace (normally `teaching/` here). Replace title, subtitle, course affiliation, author, footer and example content. The starter derives from the selected Durham design and supplied assets of 2 October 2026; its base stylesheet excludes course-specific widgets. Check it against the canonical template when that template changes.
- Use Quarto/Reveal.js when requested or already selected. Preserve PowerPoint/Beamer when that is the user's format. Preserve original exports and source presentations during conversions.

These Markdown instructions and bundled resources are the workflow; `agents/openai.yaml` supplies Codex interface metadata. Use the current assistant's available file, shell, browser and question tools. If there is no question tool, ask in chat. Resolve resource paths relative to this package and discover installed runtimes rather than assuming Windows or a named tool API. Read only the references required for the chosen work. Report unavailable checks precisely; portable instructions do not establish that every assistant host has been tested.

## Apply the Durham identity

- Use the supplied original logo from `assets/starter/assets/durham_business_school.png`, copied to the deck's `assets/durham_business_school.png`. Keep the theme's clipping of the Business School descriptor so the visible mark is **Durham University**. Keep its aspect ratio and the helper's `Durham University` alt text. Do not redraw the mark or substitute generic branding.
- Keep the 1600 x 900 layout, purple top rule, white content slides, pale gradient title slide, Aptos/Segoe UI/Arial fonts and existing readable type sizes. Use purple `#682046`, deep purple `#3e1a47`, pale purple `#f4edf2` and body text `#1f2937`.
- Keep the course name prominent on the title slide through the affiliation field. Use the actual deck footer, author and slide count. Never carry over ECON2271, Brexit or other example-course labels.
- Copy the theme and helper into each new project; add scoped local styles for that deck. Do not edit another course to create a new one. This is David's selected design, not a claim of university-wide brand approval.

## Preserve and explain the content

- Correct clear typos, repeated words and inconsistent formatting within scope; verify technical notation and flag wording whose meaning is uncertain. Preserve the teaching sequence, results and qualifications. For crowding, first shorten wording without losing meaning and improve spacing. If it remains crowded, split within an authorized revision before shrinking readable text; record changes to slide count/order.
- Verify the intended academic year or data period from the request, project and authoritative source before refreshing it. Apply verified updates without asking about each individual change. Keep course-year labels separate from historical dates, sample periods, citations and original estimates; never perform a blanket year replacement.
- Use semantic headings, lists and tables, meaningful links, checked figure descriptions and structured mathematics (MathML by default). Define symbols and state the economic point in words. Essential student explanations must remain available outside presenter-only notes.
- When redrawing economic diagrams or adding motion, read [diagrams-and-motion.md](references/diagrams-and-motion.md). Keep a complete, useful static version; animation is optional and user-controlled.

## Render and verify the delivered version

1. Resolve the installed Quarto executable from PATH or the project's runtime configuration. David's current Windows fallback is `E:/AI_tools/quarto-1.10.18/bin/quarto.cmd`; use it only if present. Render the actual `.qmd` with `quarto render`.
2. Inspect all rendered slides for content bounds and missing assets; visually inspect every converted slide, or changed slides and representative layouts for a local revision. Check the logo, course label, slide count, footer clearance, legible chart labels and equations. Check visual continuity across related slides in both directions using [visual-continuity.md](references/visual-continuity.md).
3. Check keyboard navigation, focus, alt-text accuracy, reading order and contrast. Use a development-only Quarto axe profile as a supplement; remove debug reports from the student release. Report screen-reader and Blackboard checks as untested unless actually performed.
4. For an interactive diagram, verify static load, each stage, pause/resume, manual stepping, reset/replay and leaving/re-entering the slide. Test keyboard controls and the reduced-motion/static fallback.
5. Keep `embed-resources: true` for portable HTML. Open the actual delivered HTML independently of its source assets. Check any promised offline use; external video and remote services still need network access.
   For staff editing, verify hidden presentation controls, edit/undo/preview, the saved HTML and an import/rebuild round trip using [staff-editing.md](references/staff-editing.md). Resolve source conflicts before delivery.
6. If a ZIP is requested, include exactly the agreed rendered HTML files and inspect its contents. Keep editable sources in the project. Do not publish to GitHub or upload to a teaching platform unless requested.

Finish with the deliverable link, a brief account of checks, supported content updates and any unresolved maths, links/dates/data or delivery limitation. State the scope of mathematical verification and flag calculations or derivations that could not be checked. For conversions, include the slide mapping and unresolved losses. If the optional suggestions pass has not already been selected or declined, offer it after presenting the completed baseline, without starting it. Render success alone does not establish accessibility or economic correctness.
