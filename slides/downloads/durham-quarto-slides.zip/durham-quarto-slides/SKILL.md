---
name: durham-quarto-slides
description: Create, convert or revise Durham Quarto/Reveal.js teaching slides from PowerPoint, Beamer or Quarto. Default to a light-touch conversion with consistent equation formatting, balanced layout and essential delivery checks. Offer a full maths, content, links and accessibility review only when requested; refresh dates/data and suggest teaching improvements within the selected scope.
---

# Durham Quarto slides

Use David's established Durham teaching design and preserve the requested teaching content. Explicit user choices override these defaults.

**Err on simple.** Prioritize clear explanations, concise language, readable figures and complete static slides. Add interaction or animation only within the requested scope and when a specific learning benefit justifies the extra complexity. A simpler static change wins when it teaches the same thing.

## Choose the level of work

**Light-touch conversion is the default.** Start without a mode-selection question unless the request is materially ambiguous. A request to convert, format or make a small edit does not select a full review.

| Level | Included | When to use |
| --- | --- | --- |
| **Light touch** | Preserve content and order; apply Durham branding; tidy obvious typos, equation presentation and spacing; check conversion fidelity, rendering and essential delivery behaviour. | Ordinary creation, conversion and revision. |
| **Full check** | Light-touch work plus independent calculation/derivation checks, content consistency, all external destinations, every-slide visual review, related-slide continuity and a fuller accessibility review. | The user asks for a full/thorough deck check or equivalent review. |

In either level, verify calculations and equations you introduce or materially change, repair conversion defects, and flag substantive errors noticed. Light touch does not independently rederive all preserved source maths, audit factual claims or visit every external link. Say what was and was not checked; never describe formatting consistency as mathematical verification. A maths-only audit or targeted request such as "check this equation" authorizes that check and its dependencies, not unrelated review categories.

- **Create or revise:** use the starter or existing Quarto source. Keep small changes local and reuse relevant checks for unchanged content and helpers.
- **Convert PowerPoint or Beamer:** read [conversion.md](references/conversion.md). Produce editable Quarto plus portable HTML, preserving content and logical sequence, with a compact source-to-target mapping and any conversion limitations.
- **Full check or a targeted content check:** read the relevant sections of [content-maintenance.md](references/content-maintenance.md). For full review or affected figure sequences, use [visual-continuity.md](references/visual-continuity.md). Load these detailed reviews only for the selected scope or to investigate an observed defect.
- **Refresh dates or data:** use the relevant sections of [content-maintenance.md](references/content-maintenance.md). Establish the target period and apply supported updates within that request. A refresh does not automatically select a full audit; conversion alone preserves historical evidence and administrative facts.
- **Teaching/design suggestions:** a separate optional pass, independent of the full correctness check. Read [ranked-suggestions.md](references/ranked-suggestions.md) only when requested. A quick shortlist or detailed ranked review uses extra time/tokens; prior explicit requests already count as opt-in.

Deliver the selected work before offering extras. After a light-touch handoff, briefly mention the optional full check once unless already selected or declined; do not block delivery, start it on silence, or repeatedly ask. Updating this skill does not authorize reviewing or rebuilding existing decks.

## Load the working standard

- Locate the live workspace. If present, read `_shared/templates/durham_teaching_slides.md` for the canonical design. Use `_shared/standards/teaching_slides_accessibility.md` as authoring guidance and for the selected accessibility checks; its complete review checklist belongs to the full-check level, not every light conversion. David's current workspace is `E:/AI`, but that is a local hint, not a dependency. When those optional resources are absent, use the bundled design and essential checks below with the project's own instructions.
- Identify the live project and editable `.qmd` before editing. For an existing deck, work in that source and its local assets. Do not rerun an initial import/conversion script over hand-edited slides.
- Include the staff text editor with its small top-right **Edit slides** button in requested Reveal.js decks by default. Keep the toolbar hidden until opened and suppress the entry button in presentation fullscreen and print. Read [staff-editing.md](references/staff-editing.md) for its helper, protected content, saving and importing edits into the master project. Preserve imported staff edits before rebuilding.
- For a new deck, copy `assets/starter/` relative to this skill into an empty project in the requested workspace (normally `teaching/` here). Replace title, subtitle, course affiliation, author, footer and example content. The starter derives from the selected Durham design and supplied assets of 2 October 2026; its base stylesheet excludes course-specific widgets. Check it against the canonical template when that template changes.
- Use Quarto/Reveal.js when requested or already selected. Preserve PowerPoint/Beamer when that is the user's format. Preserve original exports and source presentations during conversions.

These Markdown instructions and bundled resources are the workflow; `agents/openai.yaml` supplies Codex interface metadata. Use the current assistant's available file, shell, browser and question tools. If there is no question tool, ask in chat. Resolve resource paths relative to this package and discover installed runtimes rather than assuming Windows or a named tool API. Read only the references required for the chosen work. Report unavailable checks precisely; portable instructions do not establish that every assistant host has been tested.

## Apply the Durham identity

- Use the supplied original logo from `assets/starter/assets/durham_business_school.png`, copied to the deck's `assets/durham_business_school.png`. Keep the theme's clipping of the Business School descriptor so the visible mark is **Durham University**. Keep its aspect ratio and the helper's `Durham University` alt text. Do not redraw the mark or substitute generic branding.
- Keep the 1600 x 900 layout, purple top rule, white content slides, pale gradient title slide, Aptos/Segoe UI/Arial fonts and existing readable type sizes. Use purple `#682046`, deep purple `#3e1a47`, pale purple `#f4edf2` and body text `#1f2937`.
- Keep the course name prominent on the title slide through the affiliation field. Use the actual deck footer, author and slide count. Never carry over ECON2271, Brexit or other example-course labels.
- Copy the theme and helper into each new project; add scoped local styles for that deck. Do not edit another course to create a new one. This is David's selected design, not a claim of university-wide brand approval.

## Preserve and explain the content

- Correct clear typos and repeated words within scope; compare converted notation against the source and flag uncertain meaning. Preserve the teaching sequence, results and qualifications. Adjust layout before shortening wording or shrinking readable text. Split only within the authorized scope and record changes to slide count/order.
- **Consistent equations are a baseline requirement.** Use structured maths with one rendering method and consistent size, weight, alignment and spacing for comparable equations. Remove accidental whole-equation bold/italic emphasis introduced by conversion or surrounding Markdown. Preserve meaningful bold vectors/matrices, conventional italic variables and intentional teaching emphasis; do not flatten mathematical distinctions. Compare signs, subscripts, superscripts and symbols with the source. Formatting checks are separate from a full derivation audit.
- **Use the slide space sensibly.** Check both overcrowding and text squeezed into a small corner with excessive unused space. Balance text, equations and figures within the usable canvas; use consistent content widths and deliberate paragraph/equation spacing. Preserve logical reading order when using columns. Do not stretch sparse content merely to fill the slide or apply uniform automatic shrinking. Keep the footer, slide number and original logo clear.
- Verify the intended academic year or data period from the request, project and authoritative source before refreshing it. Apply verified updates without asking about each individual change. Keep course-year labels separate from historical dates, sample periods, citations and original estimates; never perform a blanket year replacement.
- Use semantic headings, lists and tables, meaningful links, checked figure descriptions and structured mathematics (MathML by default). Define symbols and state the economic point in words. Essential student explanations must remain available outside presenter-only notes.
- When redrawing economic diagrams or adding motion, read [diagrams-and-motion.md](references/diagrams-and-motion.md). Keep a complete, useful static version; animation is optional and user-controlled.

## Render and verify at the selected level

1. Resolve the installed Quarto executable from PATH or the project's runtime configuration. David's current Windows fallback is `E:/AI_tools/quarto-1.10.18/bin/quarto.cmd`; use it only if present. Render the actual `.qmd` with `quarto render`.
2. For **light touch**, scan the rendered overview for missing content/assets and obvious layout defects; use available bounds/image checks across the deck when cheap. For a conversion, visually inspect representative layouts and higher-risk slides with equations, dense text, tables or complex figures; for a local revision, inspect the changed slides. Check equation styling and use of space as well as clipping, logo, labels and footer clearance. Expand inspection when a defect suggests a repeated problem. For **full check**, inspect every slide and related figure sequences in both directions using [visual-continuity.md](references/visual-continuity.md).
3. In either level, preserve semantic headings, meaningful links, accurate figure descriptions, readable contrast and structured maths; check basic keyboard navigation and focus. In **full check**, run a development-only axe profile and review reading order, descriptions and equation accessibility across the deck. Run targeted accessibility checks in light touch when changed markup or a discovered issue warrants them. Remove debug reports from release output. Report screen-reader and Blackboard checks as untested unless actually performed; a full check cannot imply access to unavailable environments.
4. Verify interactions added or changed in this task, including static load, relevant stages/controls, leaving/re-entering and reduced-motion fallback. For unchanged, previously verified interactions, smoke-test the delivered deck and reuse relevant results. A full check covers all interactions in the requested deck; do not build an exhaustive new test harness for every light conversion.
5. Keep `embed-resources: true` for portable HTML. Open the actual delivered HTML independently of its source assets. Check any promised offline use; external video and remote services still need network access.
   For staff editing, use the proportionate smoke/full checks in [staff-editing.md](references/staff-editing.md). Resolve source conflicts before delivery.
6. If a ZIP is requested, include exactly the agreed rendered HTML files and inspect its contents. Keep editable sources in the project. Do not publish to GitHub or upload to a teaching platform unless requested.

Finish with the deliverable link, selected level, checks actually completed and material limitations. For light touch, state briefly that preserved maths and external sources have not received a full audit; do not label each unreviewed item a defect. Record any known unresolved error separately. For conversions, include the compact mapping and unresolved losses. Reuse existing evidence and rerender/retest only after relevant changes or failures. Render success alone does not establish accessibility or economic correctness.
