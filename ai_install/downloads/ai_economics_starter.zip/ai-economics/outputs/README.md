# Outputs

Save tables, figures and other results here.

Keep track of the script and inputs needed to reproduce each output.
