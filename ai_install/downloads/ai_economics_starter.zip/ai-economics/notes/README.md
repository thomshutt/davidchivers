# Research notes

Save questions, assumptions and your own checks here.

For the readiness check, create `first-question.md` and write down one
assumption you would challenge in Copilot's explanation of omitted-variable bias.
