# AI for economic research

This is my practice folder for the PhD economics course.

- `code/`: scripts and analysis.
- `notes/`: research questions, assumptions and notes.
- `outputs/`: tables, figures and results.

Start by asking Copilot an economics question. Save one assumption you would
challenge in `notes/first-question.md`.

Use public or synthetic material while learning. Check the code, assumptions,
sources and outputs before relying on an AI response.

This folder is local to your laptop. It contains no software, credentials,
research data or configured AI account. Running Python, R or Stata requires
the relevant software separately.
